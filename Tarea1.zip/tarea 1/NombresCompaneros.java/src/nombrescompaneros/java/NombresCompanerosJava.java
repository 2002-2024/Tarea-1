/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nombrescompaneros.java;

/**
 *
 * @author Eduardo
 */
public class NombresCompanerosJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          // Crear un arreglo para almacenar 10 nombres
        String[] nombres = new String[10];

        // Asignar nombres al arreglo
        nombres[0] = "Carlos";
        nombres[1] = "Ana";
        nombres[2] = "Luis";
        nombres[3] = "María";
        nombres[4] = "Juan";
        nombres[5] = "Elena";
        nombres[6] = "Pedro";
        nombres[7] = "Sofía";
        nombres[8] = "Miguel";
        nombres[9] = "Lucía";

        // Imprimir los nombres
        System.out.println("Nombres de mis compañeros de clase:");
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
    
}
