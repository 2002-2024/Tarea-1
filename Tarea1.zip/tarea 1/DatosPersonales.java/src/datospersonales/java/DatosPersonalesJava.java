/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package datospersonales.java;

/**
 *
 * @author Eduardo
 */
public class DatosPersonalesJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear un arreglo multidimensional para almacenar los datos personales
        String[][] datos = {
            {"Daniel", "Medina", "Electronica", "TEST"},
            {"Monica", "Jiz", "Computacion", "IMSA"},
            {"Carlos", "Perez", "Mecanica", "GM"},
            {"Ana", "Lopez", "Civil", "CONCONCRETO"},
            {"Luis", "Garcia", "Industrial", "GILDAN"}
        };

        // Imprimir los datos personales
        System.out.println("Datos personales de mis compañeros de clase:");
        for (int i = 0; i < datos.length; i++) {
            System.out.println("Nombre: " + datos[i][0]);
            System.out.println("Apellido: " + datos[i][1]);
            System.out.println("Carrera: " + datos[i][2]);
            System.out.println("Lugar de Trabajo: " + datos[i][3]);
            System.out.println();
        }
    }
    
}
