/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evaluarnotas.java;

/**
 *
 * @author Eduardo
 */
public class EvaluarNotasJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Datos de ejemplo
        String[] nombres = {"Daniel", "Monica", "Carlos", "Ana", "Luis"};
        int[] notas = {65, 89, 74, 50, 92};

        // Evaluar y imprimir si aprobaron o reprobaron
        for (int i = 0; i < nombres.length; i++) {
            String resultado = (notas[i] >= 60) ? "Aprobado" : "Reprobado";
            System.out.println(nombres[i]);
            System.out.println(notas[i]);
            System.out.println(resultado);
            System.out.println();
        }
    }
    
}
